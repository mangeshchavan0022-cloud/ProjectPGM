﻿using Microsoft.AspNetCore.Mvc;

namespace UserLogin.areas.Admin.Controllers
{
    [Area("admin")]
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Dashboard()
        {
            return RedirectToAction("Index");
        }
    }
}
