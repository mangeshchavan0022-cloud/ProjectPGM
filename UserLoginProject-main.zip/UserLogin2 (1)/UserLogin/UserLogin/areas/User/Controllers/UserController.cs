﻿using Microsoft.AspNetCore.Mvc;

namespace UserLogin.areas.User.Controllers
{
    [Area("user")]
    public class UserController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult DashboardUser()
        {
            return RedirectToAction("Index"); 
        }
    }
}
