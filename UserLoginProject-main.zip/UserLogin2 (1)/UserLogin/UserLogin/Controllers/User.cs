﻿namespace UserLogin.Controllers
{
    internal class User
    {
        public string fullName;

        public string Email { get; internal set; }
        public string UserName { get; internal set; }

        public int CheckAdmin { get; set; }
    }
}