﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages;
using UserLogin.Models;
using UserLogin.ViewModel;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace UserLogin.Controllers
{
    
    public class AccountController : Controller
    {
        private readonly SignInManager<Users> signInManager;
        private readonly UserManager<Users> userManager;
        private readonly RoleManager<IdentityRole> roleManager;

        // ✅ Correct constructor assignment
        //public AccountController(SignInManager<Users> signInManager, UserManager<Users> userManager)
        //{
        //    this.signInManager = signInManager;
        //    this.userManager = userManager;
        //}

        public AccountController(SignInManager<Users> signInManager, UserManager<Users> userManager, RoleManager<IdentityRole> roleManager)
        {
            this.signInManager = signInManager;
            this.userManager = userManager;
            this.roleManager = roleManager;
        }


        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            List<Users> users = new List<Users>();

            if (ModelState.IsValid)
            {
               

                //var result = await signInManager.PasswordSignInAsync(model.UserName, model.Password, model.CheckAdminUser, false);
                string connectionString = "Server=DESKTOP-VOHLI8R\\SQLEXPRESS;Database=PgMange;Integrated Security=True;TrustServerCertificate=true";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT PhoneNumber, UserName, PasswordHash FROM PgMange.dbo.AspNetUsers";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Users user = new Users()
                            {
                                CheckAdmin = reader["PhoneNumber"].ToString(),
                                UserName = reader["UserName"].ToString(),
                                PasswordHash = reader["PasswordHash"].ToString()

                            };

                            users.Add(user);
                        }

                        reader.Close();
                    }

                    
                    }



                }

                foreach (var user in users)
                {
                    string userName = model.UserName;

                    if (userName.Equals(user.UserName))
                    {

                        //Console.WriteLine("user: " + user.PasswordHash);
                        //Console.WriteLine("user2: " + model.Password.GetHashCode());

                        if (user.CheckAdmin.Equals("admin"))
                        {
                            Console.WriteLine("Admin Login successfull");
                            return RedirectToAction("Index", "Admin", new { area = "Admin" });
                        }
                        else if (user.CheckAdmin.Equals("user"))
                        {
                            return RedirectToAction("Index", "User", new { area="User"});
                        }



                }


                // Use variable 'model', not 'Model'
            }

            ModelState.AddModelError("", "Email or Password is Incorrect");
            return View(model);
        }




        //[HttpGet]
        public IActionResult Resigster()
        {
            return View();
        }


        //[HttpPost]
        public IActionResult Features()
        {
            return RedirectToAction("Index", "Admin");
        }



        [HttpPost]
        public async Task<IActionResult> Resigster(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                // ✅ Create user instance
                var user = new Users
                {
                    FullName = model.Name,
                    UserName = model.Email,
                    Email = model.Email,
                    PhoneNumber = (model.CheckAdmin == 0) ? "admin" : "user"
                };

                var result = await userManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
                {
                    var roleExist = await roleManager.RoleExistsAsync("User");

                    if (!roleExist)
                    {
                        var role = new IdentityRole("user");
                        await roleManager.CreateAsync(role);
                    }

                    await userManager.AddToRoleAsync(user, "user");

                    return RedirectToAction("Login", "Account");
                }
                else
                {
                    foreach (var erro in result.Errors)
                    {
                        ModelState.AddModelError("", erro.Description);
                    }
                    return View(model);
                }
            }

            return View(model);
        }

        public IActionResult VerifEmail()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> VerifEmail(VerifyEmailViewModel model)
        {
            if (ModelState.IsValid)
            {

                var users = await userManager.FindByNameAsync(model.Email);
                if (users == null)
                {
                    ModelState.AddModelError("", "something is wrong!");
                    return View(model);
                }
                else
                {
                    return RedirectToAction("ChanagePassword", "Account", new { username = users.UserName });
                }
            }
            return View(model);


        }

        public IActionResult ChanagePassword(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                return RedirectToAction("VerifEmail,Account");
            }
            return View(new ChangePasswordViewModel { Email = username });
        }
        [HttpPost]
        public async Task<IActionResult> ChanagePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var user = await userManager.FindByNameAsync(model.Email);
                if (user == null)
                {
                    var result = await userManager.RemovePasswordAsync(user);
                    if (result.Succeeded)
                    {
                        result=await userManager.AddPasswordAsync(user,model.NewPassword);
                        return RedirectToAction("Login","Account");
                    }
                    else
                    {
                        foreach (var erro in result.Errors)
                        {
                            ModelState.AddModelError("", erro.Description);
                        }
                        return View(model);
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Email is not Found!");
                    return View(model);

                }
            }
            else
            {
                ModelState.AddModelError("", "Something went wrong try agin");
                return View(model);

            }

        }
        public async Task<IActionResult>Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Index","Home");
        }
    }
}