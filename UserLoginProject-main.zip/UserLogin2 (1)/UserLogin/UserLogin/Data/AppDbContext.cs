﻿//using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore;
//using UserLogin.Models;

//namespace UserLogin.Data
//{
//    public class AppDbContext:IdentityDbContext<Users>
//    {
//         public AppDbContext(DbContextOptions<AppDbContext> options):base(options)
//        {

//        }
//    }


//}
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using UserLogin.Models;

namespace UserLogin.Data
{
    public class AppDbContext : IdentityDbContext<Users>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {

        }

        // Example DbSet
        // public DbSet<Product> Products { get; set; }
    }
}
