﻿
using System.ComponentModel.DataAnnotations;
namespace UserLogin.ViewModel
{
    public class RegisterViewModel
    {
        //[Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }
        //[Required(ErrorMessage = "Email is required")]
        [EmailAddress]
        public string Email { get; set; }


        //[Required(ErrorMessage = "Usertype is required")]
        public int CheckAdmin { get; set; }

        //[Required(ErrorMessage = "Password is required")]
        //[StringLength( 40,MinimumLength =8,ErrorMessage ="The {0} must be at {2} and at max{1} chaaractres long.")]
        //[DataType(DataType.Password)]
        //[Compare("confirmPassword",ErrorMessage ="The password and confirmation password do not match.")]
        public string Password { get; set; }


        //[Required(ErrorMessage = "Confirm Password is required")]
        //[DataType(DataType.Password)]
        //[Display(Name = "Confirm  Password")]
        public string confirmPassword { get; set; } 
    }
}
