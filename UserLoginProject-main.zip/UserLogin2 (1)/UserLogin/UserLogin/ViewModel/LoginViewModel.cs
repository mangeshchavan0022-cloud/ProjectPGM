﻿
using System.ComponentModel.DataAnnotations;    
namespace UserLogin.ViewModel
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "User Name is required")]
        [EmailAddress]
        public String UserName { get; set; }
        
        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]   
        public string Password { get; set; }

        [Display(Name = "Remember Me")]
        public bool CheckAdminUser { get; set; }
    }
}
