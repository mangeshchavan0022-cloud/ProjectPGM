﻿using Microsoft.AspNetCore.Identity;

namespace UserLogin.Models
{
    public class Users: IdentityUser
    {
        public string FullName { get; set; }

        public string Email { get; set; }

        public string UserName { get; set; }

        public string CheckAdmin { get; set; }

    }
}
